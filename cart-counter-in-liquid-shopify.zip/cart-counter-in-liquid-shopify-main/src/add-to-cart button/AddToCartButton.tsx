export function AddToCartButton() {
  return <button>Add to cart</button>;
}
